import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px
from sqlalchemy import create_engine, text
import urllib

# --- SQL Server connection using Windows Authentication ---
params = urllib.parse.quote_plus(
    "DRIVER={ODBC Driver 17 for SQL Server};"
    "SERVER=DESKTOP-SSHQH3D\\SQLEXPRESS;"
    "DATABASE=hardware_shop_management_system;"
    "Trusted_Connection=yes;"
)
engine = create_engine(f"mssql+pyodbc:///?odbc_connect={params}")

# --- Streamlit page setup ---
st.set_page_config(page_title="Hardware BI Dashboard", layout="wide")
st.title("\U0001f3ec Hardware Shop Business Intelligence Dashboard")

# --- User-friendly filter area ---
with st.expander("📅 Filter Options", expanded=True):
    col1, col2 = st.columns(2)
    with col1:
        year = st.selectbox("Select Year", [2024, 2025], index=0, label_visibility="visible", placeholder="Select an option", help="Choose an item from the dropdown")
    with col2:
        month = st.slider("Select Month", min_value=1, max_value=12, value=1)

# --- Test DB connection ---
try:
    with engine.connect() as conn:
        result = conn.execute(text("SELECT GETDATE() AS now")).fetchone()
        st.success(f"\u2705 Connected to SQL Server at: {result.now}")
except Exception as e:
    st.error(f"\u274c Connection failed: {e}")
    st.stop()

# --- Monthly Sales ---
with engine.connect() as conn:
    result = conn.execute(
        text("SELECT dbo.fn_GetMonthlySales(:year, :month) AS monthly_sales"),
        {"year": year, "month": month}
    ).fetchone()
    monthly_sales = result.monthly_sales
st.metric("\U0001f9fe Monthly Sales", f"LKR {monthly_sales:,.2f}")

# --- Top 5 Employees ---
col1, col2 = st.columns(2)

with col1:
    st.subheader("\U0001f3c5 Top 5 Employees by Sales")
    with engine.connect() as conn:
        df_emp = pd.read_sql(
            text("""
                SELECT TOP 5 
                    e.first_name + ' ' + e.last_name AS employee_name,
                    SUM(so.total_amount) AS total_sales
                FROM EMPLOYEE e
                JOIN SALES_ORDER so ON e.employee_id = so.employee_id
                WHERE YEAR(so.order_date) = :year
                GROUP BY e.first_name, e.last_name
                ORDER BY total_sales DESC
            """), conn, params={"year": year}
        )
    fig_emp = px.bar(df_emp, x="employee_name", y="total_sales", color="employee_name",
                     labels={"total_sales": "Total Sales (LKR)"})
    st.plotly_chart(fig_emp, use_container_width=True)

# --- Sales Orders by Month ---
with col2:
    st.subheader("\U0001f4ca Sales Orders by Month")
    with engine.connect() as conn:
        df_month = pd.read_sql(
            text("""
                SELECT MONTH(order_date) AS month, COUNT(*) AS order_count
                FROM SALES_ORDER
                WHERE YEAR(order_date) = :year
                GROUP BY MONTH(order_date)
                ORDER BY month
            """), conn, params={"year": year}
        )
    fig_month = px.line(df_month, x="month", y="order_count", markers=True,
                        labels={"month": "Month", "order_count": "Orders"})
    st.plotly_chart(fig_month, use_container_width=True)

# --- Inventory Overview ---
st.subheader("\U0001f4e6 Inventory Stock Status")
with engine.connect() as conn:
    df_inv = pd.read_sql(
        text("""
            SELECT 
                p.product_name,
                c.category_name,
                i.quantity_on_hand,
                i.minimum_stock_level,
                CASE 
                    WHEN i.quantity_on_hand = 0 THEN 'Out of Stock'
                    WHEN i.quantity_on_hand <= i.minimum_stock_level THEN 'Low Stock'
                    WHEN i.quantity_on_hand <= i.minimum_stock_level * 2 THEN 'Medium Stock'
                    ELSE 'High Stock'
                END AS stock_status
            FROM PRODUCT p
            JOIN INVENTORY i ON p.inventory_id = i.inventory_id
            JOIN CATEGORY c ON p.category_id = c.category_id
        """), conn
    )
fig_stock = px.pie(df_inv, names='stock_status', title="Stock Status Distribution")
st.plotly_chart(fig_stock, use_container_width=True)
st.dataframe(df_inv[['product_name', 'category_name', 'quantity_on_hand', 'minimum_stock_level', 'stock_status']])

# --- Show and manage customers ---
st.subheader("👥 All Customers")
with engine.connect() as conn:
    df_customers = pd.read_sql("SELECT * FROM CUSTOMER", conn)
st.dataframe(df_customers, use_container_width=True)
selected_customer = st.selectbox("Select Customer", df_customers['customer_id'].astype(str) + " - " + df_customers['first_name'] + " " + df_customers['last_name'])
selected_cid = int(selected_customer.split(" - ")[0])
edit_customer = df_customers[df_customers['customer_id'] == selected_cid].iloc[0]
with st.expander("Edit Customer"):
    new_first = st.text_input("First Name", edit_customer['first_name'])
    new_last = st.text_input("Last Name", edit_customer['last_name'])
    new_email = st.text_input("Email", edit_customer['email'])
    new_address = st.text_input("Address", edit_customer['address'])
    new_type = st.selectbox("Customer Type", ["Individual", "Contractor", "Business"], index=["Individual", "Contractor", "Business"].index(edit_customer['customer_type']))
    if st.button("Update Customer"):
        with engine.connect() as conn:
            conn.execute(text("""
                UPDATE CUSTOMER SET first_name=:f, last_name=:l, email=:e, address=:a, customer_type=:t
                WHERE customer_id=:cid
            """), {"f": new_first, "l": new_last, "e": new_email, "a": new_address, "t": new_type, "cid": selected_cid})
        st.success("Customer updated.")
    if st.button("Delete Customer"):
        with engine.connect() as conn:
            conn.execute(text("DELETE FROM CUSTOMER WHERE customer_id=:cid"), {"cid": selected_cid})
        st.success("Customer deleted.")

# --- Show and manage products ---
st.subheader("🛍️ All Products")
with engine.connect() as conn:
    df_products = pd.read_sql("SELECT * FROM PRODUCT", conn)
st.dataframe(df_products, use_container_width=True)
selected_product = st.selectbox("Select Product", df_products['product_id'].astype(str) + " - " + df_products['product_name'])
selected_pid = int(selected_product.split(" - ")[0])
edit_product = df_products[df_products['product_id'] == selected_pid].iloc[0]
with st.expander("Edit Product"):
    new_name = st.text_input("Product Name", edit_product['product_name'])
    new_brand = st.text_input("Brand", edit_product['brand'])
    new_price = st.number_input("Unit Price", value=float(edit_product['unit_price']))
    new_reorder = st.number_input("Reorder Level", value=int(edit_product['reorder_level']))
    new_unit = st.text_input("Unit of Measure", edit_product['unit_of_measure'])
    new_desc = st.text_area("Description", edit_product['description'] or "")
    new_cat = st.number_input("Category ID", value=int(edit_product['category_id']))
    new_inv = st.number_input("Inventory ID", value=int(edit_product['inventory_id']))
    if st.button("Update Product"):
        with engine.connect() as conn:
            conn.execute(text("""
                UPDATE PRODUCT SET product_name=:pn, brand=:b, unit_price=:up, reorder_level=:r,
                unit_of_measure=:u, description=:d, category_id=:c, inventory_id=:i
                WHERE product_id=:pid
            """), {"pn": new_name, "b": new_brand, "up": new_price, "r": new_reorder, "u": new_unit,
                  "d": new_desc, "c": new_cat, "i": new_inv, "pid": selected_pid})
        st.success("Product updated.")
    if st.button("Delete Product"):
        with engine.connect() as conn:
            conn.execute(text("DELETE FROM PRODUCT WHERE product_id=:pid"), {"pid": selected_pid})
        st.success("Product deleted.")

# --- Customer Sales Summary ---
st.subheader("\U0001f4cb Customer Sales Summary")
try:
    with engine.connect() as conn:
        df_summary = pd.read_sql(text("SELECT TOP 10 * FROM vw_CustomerSalesSummary"), conn)
    st.dataframe(df_summary)
except Exception as e:
    st.error(f"Error loading summary: {e}")
